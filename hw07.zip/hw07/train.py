import os
import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import datasets, transforms

# ===================== 【固定为你电脑的真实路径】 =====================
BASE_DIR = r"C:\Users\Asus\Downloads\archive.zip\archive\chest_xray"

IMAGE_SIZE = (150, 150)
BATCH_SIZE = 16
EPOCHS = 5
LEARNING_RATE = 0.001
DEVICE = torch.device("cpu")

# ===================== 数据预处理 =====================
train_transform = transforms.Compose([
    transforms.Resize(IMAGE_SIZE),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
])

val_test_transform = transforms.Compose([
    transforms.Resize(IMAGE_SIZE),
    transforms.ToTensor(),
])

# ===================== 加载数据集 =====================
full_train = datasets.ImageFolder(os.path.join(BASE_DIR, "train"), transform=train_transform)
test_dataset = datasets.ImageFolder(os.path.join(BASE_DIR, "test"), transform=val_test_transform)

# 8:2 分训练集和验证集
train_size = int(0.8 * len(full_train))
val_size = len(full_train) - train_size
train_dataset, val_dataset = torch.utils.data.random_split(full_train, [train_size, val_size])

train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False)
test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)

# ===================== 输出数据集信息 =====================
print("\n===== 数据集样本数 =====")
print(f"训练集: {len(train_dataset)}")
print(f"验证集: {len(val_dataset)}")
print(f"测试集: {len(test_dataset)}")
print("类别:", full_train.class_to_idx)

# ===================== 轻量级CNN模型 =====================
class Net(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(3, 16, 3)
        self.pool = nn.MaxPool2d(2, 2)
        self.conv2 = nn.Conv2d(16, 32, 3)
        self.fc1 = nn.Linear(32 * 36 * 36, 128)
        self.fc2 = nn.Linear(128, 1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        x = self.pool(torch.relu(self.conv1(x)))
        x = self.pool(torch.relu(self.conv2(x)))
        x = torch.flatten(x, 1)
        x = torch.relu(self.fc1(x))
        x = self.sigmoid(self.fc2(x))
        return x

model = Net().to(DEVICE)
criterion = nn.BCELoss()
optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)

# ===================== 训练 =====================
print("\n开始训练...")
train_acc_list = []
val_acc_list = []

for epoch in range(EPOCHS):
    model.train()
    correct = 0
    total = 0
    for images, labels in train_loader:
        images, labels = images.to(DEVICE), labels.float().unsqueeze(1).to(DEVICE)
        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        predicted = (outputs > 0.5).float()
        total += labels.size(0)
        correct += (predicted == labels).sum().item()
    train_acc = correct / total

    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for images, labels in val_loader:
            images, labels = images.to(DEVICE), labels.float().unsqueeze(1).to(DEVICE)
            outputs = model(images)
            predicted = (outputs > 0.5).float()
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
    val_acc = correct / total

    train_acc_list.append(train_acc)
    val_acc_list.append(val_acc)
    print(f"Epoch {epoch+1} 训练准确率: {train_acc:.4f} | 验证准确率: {val_acc:.4f}")

# ===================== 测试集评估 =====================
print("\n===== 测试集结果 =====")
model.eval()
all_preds = []
all_labels = []
with torch.no_grad():
    for images, labels in test_loader:
        images = images.to(DEVICE)
        outputs = model(images)
        preds = (outputs > 0.5).cpu().numpy().astype(int).ravel()
        all_preds.extend(preds)
        all_labels.extend(labels.numpy())

# 计算指标
TP = TN = FP = FN = 0
for p, t in zip(all_preds, all_labels):
    if p == 1 and t == 1: TP += 1
    elif p == 0 and t == 0: TN += 1
    elif p == 1 and t == 0: FP += 1
    elif p == 0 and t == 1: FN += 1

acc = (TP + TN) / (TP + TN + FP + FN)
precision = TP / (TP + FP) if (TP + FP) != 0 else 0
recall = TP / (TP + FN) if (TP + FN) != 0 else 0
f1 = 2 * precision * recall / (precision + recall) if (precision + recall) != 0 else 0

print(f"准确率: {acc:.4f}")
print(f"精确率: {precision:.4f}")
print(f"召回率: {recall:.4f}")
print(f"F1分数: {f1:.4f}")

# ===================== 保存图片到 figures =====================
os.makedirs("figures", exist_ok=True)

# 训练曲线
plt.figure()
plt.plot(train_acc_list, label="Train Acc")
plt.plot(val_acc_list, label="Val Acc")
plt.legend()
plt.savefig("figures/acc_curve.png")
plt.close()

# 混淆矩阵
plt.figure()
plt.imshow([[TN, FP], [FN, TP]], cmap="Blues")
plt.title("Confusion Matrix")
plt.savefig("figures/confusion.png")
plt.close()

print("\n✅ 运行完成！图片已保存到 figures 文件夹")