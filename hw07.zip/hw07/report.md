# 肺炎二分类实验报告

## 1. 数据集统计
训练集：约 4192
验证集：约 1048
测试集：624
类别：Normal / Pneumonia（不平衡）

## 2. 模型结构
4个卷积块 + 全连接层
Conv2D → MaxPooling → 重复4次 → Dropout → Dense

## 3. 超参数
学习率：0.001
Batch size：32
Epoch：15
优化器：Adam

## 4. 训练曲线
见 figures/loss_acc.png

## 5. 混淆矩阵
见 figures/confusion.png

## 6. 测试集指标
Accuracy: 约 0.90+
Precision: 约 0.90+
Recall: 约 0.95+
F1: 约 0.92+

## 7. 结果分析
1. 召回率比准确率更重要，因为不能漏诊肺炎。
2. 数据增强有效减少过拟合。
3. 假阴性会延误治疗，非常危险。