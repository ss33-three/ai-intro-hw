# HW07 肺炎二分类模型

## 文件夹结构
hw07/
├── figures/        训练曲线、混淆矩阵
├── train.py        训练主程序
├── requirements.txt 依赖
├── report.md       实验报告
└── README.md

## 环境安装
pip install -r requirements.txt

## 运行方式
python train.py

## 数据集路径
C:\Users\Asus\Downloads\archive\chest_xray

## 最终测试指标
Accuracy: ~0.90+
Precision: ~0.90+
Recall: ~0.95+
F1: ~0.92+